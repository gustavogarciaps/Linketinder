create function criar_correspondencia_candidato_vaga() returns trigger
    language plpgsql
as
$$
DECLARE
  empresas_candidatos_id INTEGER;
BEGIN
  IF NEW.curtida = TRUE 
  THEN
    SELECT ec.id INTO empresas_candidatos_id
    FROM empresas_candidatos ec
    WHERE ec.candidatos_id = NEW.candidatos_id
      AND ec.empresas_id = (
      SELECT empresas_id FROM vagas WHERE id = NEW.vagas_id
    )
      AND ec.curtida = TRUE;

    IF empresas_candidatos_id IS NOT NULL THEN
      INSERT INTO correspondencias (empresas_candidatos_id, candidatos_vagas_id)
      VALUES (empresas_candidatos_id, NEW.id);
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

alter function criar_correspondencia_candidato_vaga() owner to postgres;

