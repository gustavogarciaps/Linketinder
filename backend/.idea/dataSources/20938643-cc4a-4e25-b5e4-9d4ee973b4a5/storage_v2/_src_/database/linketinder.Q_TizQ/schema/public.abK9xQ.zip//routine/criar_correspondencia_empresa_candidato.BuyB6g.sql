create function criar_correspondencia_empresa_candidato() returns trigger
    language plpgsql
as
$$
DECLARE
  candidatos_vagas_id INTEGER;
BEGIN
  IF NEW.curtida = TRUE THEN
    SELECT cv.id INTO candidatos_vagas_id
    FROM candidatos_vagas cv
    WHERE cv.candidatos_id = NEW.candidatos_id
      AND cv.curtida = TRUE;
    
    IF candidatos_vagas_id IS NOT NULL THEN
      INSERT INTO correspondencias (empresas_candidatos_id, candidatos_vagas_id)
      VALUES (NEW.id, candidatos_vagas_id);
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

alter function criar_correspondencia_empresa_candidato() owner to postgres;

